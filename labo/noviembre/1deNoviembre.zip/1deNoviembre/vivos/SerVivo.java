package personas;

public interface SerVivo {

    int getEdad();

    String getNombre();

    String getLugarDondeVive();

}
