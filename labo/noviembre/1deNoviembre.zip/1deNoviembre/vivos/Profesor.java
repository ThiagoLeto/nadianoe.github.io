package personas;

public class Profesor extends SerHumano {

    private String materia;

    public Profesor(String nombre, String apellido, int edad, String materia){
        super(nombre,apellido,edad);
        this.materia = materia;
    }

    @Override
    public String getLugarDondeVive() {
        return null;
    }
}




