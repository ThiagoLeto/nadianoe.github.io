package figuras;

public class Rectangulo extends Figura2D {

    private double base;
    private double altura;

    public Rectangulo(double base, double altura){
        super(0,0,"rectángulo");
        this.base = base;
        this.altura = altura;
    }

    @Override
    public void imprimirCaracteristica() {
        System.out.println("área: " + base * altura);
    }
}
