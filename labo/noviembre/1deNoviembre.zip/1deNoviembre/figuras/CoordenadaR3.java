package figuras;

public class CoordenadaR3 implements Coordenada{

    private double x;
    private double y;
    private double z;

    public CoordenadaR3(double x, double y, double z){
        this.x = x;
        this.y = y;
        this.z = z;
    }

    @Override
    public void imprimirPosicion() {
        System.out.println("valor en eje x: " + x);
        System.out.println("valor en eje y: " + y);
        System.out.println("valor en eje z: " + z);
    }

    @Override
    public boolean seUbicaEnLaOrdenadaAlOrigen() {
        boolean todosValenCero = (x == 0 && y == 0 && z == 0);
        return todosValenCero;
    }
}
