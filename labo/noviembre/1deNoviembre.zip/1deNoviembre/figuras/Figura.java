package figuras;

public abstract class Figura extends ObjetoGrafico {

    private Coordenada posicion;

    public Figura(Coordenada posicion, String nombre, String categoria) {
        super(nombre,categoria);
        this.posicion = posicion;
    }

    public abstract void moverHacia(double... valoresEnEje);

    public abstract void imprimirCaracteristica();

    public Coordenada getPosicion(){
        return this.posicion;
    }

    public void setPosicion(Coordenada posicion) {
        this.posicion = posicion;
    }


}
