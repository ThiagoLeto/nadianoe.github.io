package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        Figura f1 = new Circulo(2);
        Figura f2 = new Rectangulo(2,4);
        Figura f3 = new Esfera(3);
        Figura f4 = new Cono(2,5);

        f1.getPosicion().imprimirPosicion();

        Calculadora c = new Calculadora();
        c.agregarFiguras(f1,f2,f3,f4);
        c.imprimirDimensionesDeFiguras();

        f1.moverHacia(1,1);
        //f1.moverHacia(new CoordenadaR2(2,2));
        Circulo circulo = (Circulo) f1;
        circulo.moverHacia(new CoordenadaR2(2,2));

        List<Integer> lista = new ArrayList<>();
        Coordenada coordenada1 = new CoordenadaR2(1,1);
        Coordenada coordenada2 = new CoordenadaR3(1,1,1);






    }
}
