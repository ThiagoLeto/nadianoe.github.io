package figuras;

import static java.lang.Math.PI;
import static java.lang.Math.pow;

public class Esfera extends Figura3D {

    private double radio;

    public Esfera(double radio) {
        super(0,0,0,"esfera");
        this.radio = radio;
    }

    @Override
    public void imprimirCaracteristica() {
        double volumen = 0.75 * PI * pow(radio,3);
        System.out.println( "volumen: " + volumen );
    }


}
