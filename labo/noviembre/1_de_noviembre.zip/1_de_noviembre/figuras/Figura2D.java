package figuras;

public class Figura2D extends Figura {

    public Figura2D(double x, double y, String nombre){
        super(new CoordenadaR2(x,y),nombre,"geometría bidimensional");
    }

    @Override
    public void moverHacia(double... valoresEnEje) {
        double x = valoresEnEje[0];
        double y = valoresEnEje[1];
        this.setPosicion(new CoordenadaR2(x,y));
    }

    public void moverHacia(CoordenadaR2 nuevaPosicion) {
        this.setPosicion(nuevaPosicion);
    }

    @Override
    public void imprimirCaracteristica() {
        System.out.println("área");
    }
}
