package figuras;

import java.util.HashSet;

public class Calculadora {

    private HashSet<Figura> figuras;

    public Calculadora(){
        this.figuras = new HashSet<>();
    }

    public void setFiguras(HashSet<Figura> figuras){
        this.figuras = figuras;
    }

    public void agregarFiguras(Figura... figuras){
        for (Figura unaFigura : figuras ) {
            this.figuras.add(unaFigura);
        }
    }

    public void imprimirDimensionesDeFiguras(){
        for ( Figura unaFigura : figuras ) {
            System.out.println("nombre: " + unaFigura.getNombre());
            unaFigura.imprimirCaracteristica();
        }
    }
}
