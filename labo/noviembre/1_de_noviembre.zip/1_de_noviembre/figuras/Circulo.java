package figuras;

import static java.lang.Math.PI;
import static java.lang.Math.pow;

public class Circulo extends Figura2D {

    private double radio;

    public Circulo(double radio){
        super(0,0,"círculo");
        this.radio = radio;
    }

    @Override
    public void imprimirCaracteristica() {
        System.out.println("área: " + PI * pow(radio,2));
    }

    public boolean radioMayorACinco(){
        return radio > 5;
    }

}
