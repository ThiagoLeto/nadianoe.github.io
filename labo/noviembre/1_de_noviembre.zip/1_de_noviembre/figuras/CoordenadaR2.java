package figuras;

public class CoordenadaR2 implements Coordenada {

    private double x;
    private double y;

    public CoordenadaR2(double x, double y){
        this.x = x;
        this.y = y;
    }

    @Override
    public void imprimirPosicion() {
        System.out.println("valor en eje x: " + x);
        System.out.println("valor en eje y: " + y);
    }

    @Override
    public boolean seUbicaEnLaOrdenadaAlOrigen() {
        boolean todosValenCero = (x == 0 && y == 0);
        return todosValenCero;
    }
}
