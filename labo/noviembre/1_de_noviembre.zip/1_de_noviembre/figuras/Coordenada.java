package figuras;

public interface Coordenada {

    public void imprimirPosicion();
    public boolean seUbicaEnLaOrdenadaAlOrigen();

}
