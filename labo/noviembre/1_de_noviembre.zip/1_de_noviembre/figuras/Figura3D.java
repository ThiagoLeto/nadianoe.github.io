package figuras;

public class Figura3D extends Figura {

    public Figura3D(double x, double y, double z, String nombre){
        super(new CoordenadaR3(x,y,z),nombre,"geometría tridimencional");
    }

    @Override
    public void moverHacia(double... valoresEnEje) {
        double x = valoresEnEje[0];
        double y = valoresEnEje[1];
        double z = valoresEnEje[2];
        this.setPosicion(new CoordenadaR3(x,y,z));
    }

    public void moverHacia(CoordenadaR3 nuevaPosicion) {
        this.setPosicion(nuevaPosicion);
    }

    @Override
    public void imprimirCaracteristica() {
        System.out.println("volumen");
    }
}
