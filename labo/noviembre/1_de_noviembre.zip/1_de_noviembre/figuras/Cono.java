package figuras;

import static java.lang.Math.PI;
import static java.lang.Math.pow;

public class Cono extends Figura3D {

    private double radio;
    private double altura;

    public Cono(double radio, double altura) {
        super(0,0,0,"cono");
        this.radio = radio;
        this.altura = altura;
    }

    @Override
    public void imprimirCaracteristica() {
        System.out.println("volumen: " + 0.33333 * PI * pow(radio,2) * altura);
    }
}
