package personas;

public interface Planta extends SerVivo {

    boolean esVenenosa();

}
