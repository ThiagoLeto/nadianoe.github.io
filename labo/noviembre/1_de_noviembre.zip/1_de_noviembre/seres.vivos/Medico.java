package personas;

public abstract class Medico extends SerHumano{

    public Medico(String nombre, String apellido, int edad) {
        super(nombre, apellido, edad);
    }

    @Override
    public String getLugarDondeVive() {
        return null;
    }
}
