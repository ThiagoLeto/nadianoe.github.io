package personas;

public class AnimalAcuatico implements Animal {

    @Override
    public int cantidadDeExtremidades() {
        return 0;
    }

    @Override
    public String getTipoDeAlimentacion() {
        return null;
    }

    @Override
    public int getEdad() {
        return 0;
    }

    @Override
    public String getNombre() {
        return null;
    }

    @Override
    public String getLugarDondeVive() {
        return null;
    }
}
