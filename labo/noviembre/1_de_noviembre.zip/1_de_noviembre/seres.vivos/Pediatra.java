package personas;

public class Pediatra  extends Medico {

    public Pediatra(String nombre, String apellido, int edad) {
        super(nombre, apellido, edad);
    }

    @Override
    public String getIntereses() {
        return null;
    }

}
