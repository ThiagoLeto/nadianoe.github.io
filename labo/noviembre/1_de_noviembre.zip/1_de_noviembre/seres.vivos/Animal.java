package personas;

public interface Animal extends SerVivo{

    int cantidadDeExtremidades();

    String getTipoDeAlimentacion();

}
